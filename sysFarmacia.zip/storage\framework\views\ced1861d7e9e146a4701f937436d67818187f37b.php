

<?php $__env->startSection('title', 'Empresa'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::open(['url' => '/empresa/1', 'method' => 'PATCH']); ?>

    <div class="col-md-8">
        <div class="card">
            <img src="#" alt="">
            <div class="card-body">
                <h5 class="card-title"><b>Sistema Farmacia</b></h5>
            </div>
            <ul class="list-group list-group-flush">            
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <?php echo e(Form::label('nombre', 'Nombre/Razon Social')); ?>

                                <?php echo e(Form::text('nombre',$empresa->nombre,['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <?php echo e(Form::label('nit', 'Nit')); ?>

                                <?php echo e(Form::text('nit',$empresa->nit,['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <?php echo e(Form::label('correo', 'Correo')); ?>

                            <?php echo e(Form::text('correo',$empresa->correo,['class'=>'form-control','required'])); ?>

                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <?php echo e(Form::label('sistema', 'Sistema')); ?>

                                <?php echo e(Form::text('sistema',$empresa->sistema,['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <?php echo e(Form::label('codigo_sistema', 'Codigo Sistema')); ?>

                                <?php echo e(Form::text('codigo_sistema',$empresa->codigo_sistema,['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <?php echo e(Form::label('version', 'version')); ?>

                                <?php echo e(Form::text('version',$empresa->version,['class'=>'form-control','required'])); ?>

                            </div>
                        </div>
                    </div>                
                    
                </li>
            </ul>        
            <div class="card-footer">
                <div class="row">
                    <div class="col-sm-10"></div>
                    <div class="col-sm-2">
                        <input type="submit" value="Guardar" class="btn btn-info">
                    </div>
                </div>            
            </div>
        </div>
    </div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/empresa/edit.blade.php ENDPATH**/ ?>