
<?php $__env->startSection('title', 'Importar'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!DOCTYPE html>
    <html lang="es">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            
        </head>
        <body>
            <div class="flex-center position-ref full-height">
                <?php if(session('success_message')): ?>
                    <?php $__env->startSection('js'); ?>
                        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                        <script>
                            Swal.fire(
                                'Importacion de Medicamentos',
                                "<?php echo e(session('success_message')); ?>",
                                'success')
                        </script>
                    <?php $__env->stopSection(); ?>
                <?php endif; ?>
                <?php if(session('error_message')): ?>
                    <?php $__env->startSection('js'); ?>
                        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                        <script>
                            Swal.fire(
                                'Importacion de Medicamentos',
                                "<?php echo e(session('error_message')); ?>",
                                'error')
                        </script>
                    <?php $__env->stopSection(); ?>
                <?php endif; ?>
                <div class="container mt-5">
                    <h3>Importar Medicamentos</h3>
                    <?php echo Form::open(['url' => '/importM', 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

                        <?php echo e(Form::token()); ?> 
                            <div class="row">
                                <div class="col-12">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">MEDICAMENTO</th>
                                            <th scope="col">PRESENTACION</th>
                                            <th scope="col">CANTIDAD</th>
                                            <th scope="col">LABORATORIO</th>
                                            <th scope="col">LOTE</th>
                                            <th scope="col">FECHA_VENCIMIENTO</th>
                                            <th scope="col">PRECIO_COMPRA</th>
                                            <th scope="col">PRECIO_VENTA</th>
                                            <th scope="col">VALOR_TOTAL</th>                                            
                                          </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <div class="custom-file">
                                        <?php echo e(Form::file('cover')); ?>                                        
                                    </div>
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary">Importar</button>
                                    </div>
                                </div>
                            </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </body>
    </html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/medicamento/importMedicamento.blade.php ENDPATH**/ ?>