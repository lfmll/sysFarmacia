
<?php $__env->startSection('css'); ?>
    <style>             
        .small-box>.inner{
            padding: 10px;
        }
        ion-icon {
            font-size: 100px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Reportes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3 col-xs-6">        
            <div class="small-box bg-primary">
                <div class="inner">
                    <h3><?php echo e($cantVentas); ?></h3>
                    <p>Cantidad de Ventas</p>
                </div>
                <div class="icon">
                    <ion-icon name="cart-outline"></ion-icon>
                </div>                
                <a href="<?php echo e(url('reporteVentaDia')); ?>" class="small-box-footer">Reporte Diario <i class="fa fa-arrow-circle-down"></i></a>
                <a href="<?php echo e(url('reporteVentaMensual')); ?>" class="small-box-footer">Reporte Mensual <i class="fa fa-arrow-circle-down"></i></a>
                <a href="<?php echo e(url('reporteVentaAnual')); ?>" class="small-box-footer">Reporte Anual <i class="fa fa-arrow-circle-down"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php echo e($cantCompras); ?></h3>
                    <p>Cantidad de Compras</p>                    
                </div>
                <div class="icon">
                    <ion-icon name="bag-outline"></ion-icon>
                </div>
                <a href="<?php echo e(url('reporteCompraDia')); ?>" class="small-box-footer">Reporte Diario <i class="fa fa-arrow-circle-down"></i></a>
                <a href="<?php echo e(url('reporteCompraMensual')); ?>" class="small-box-footer">Reporte Mensual <i class="fa fa-arrow-circle-down"></i></a>
                <a href="<?php echo e(url('reporteCompraAnual')); ?>" class="small-box-footer">Reporte Anual <i class="fa fa-arrow-circle-down"></i></a>                
            </div>            
        </div>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-warning text-white">
                <div class="inner">
                    <h3><?php echo e($cantCierres); ?></h3>
                    <p>Caja</p>
                </div>
                <div class="icon">
                    <ion-icon name="calculator-outline"></ion-icon>
                </div>
                <a href="<?php echo e(url('reporteCierreAnterior')); ?>" class="small-box-footer">Reporte <i class="fa fa-arrow-circle-down"></i></a>
            </div>            
        </div>
        <div class="col-lg-3 col-xs-6">
            <div class="small-box bg-red">
                <div class="inner">
                    <h3><?php echo e($cantLotes); ?></h3>
                    <p>Lote en Vencimiento</p>
                </div>
                <div class="icon">
                    <ion-icon name="today-outline"></ion-icon>
                </div>
                <a href="<?php echo e(url('reporteLotesVencimiento')); ?>" class="small-box-footer">Reporte <i class="fa fa-arrow-circle-down"></i></a>                
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/reporte/reporte.blade.php ENDPATH**/ ?>