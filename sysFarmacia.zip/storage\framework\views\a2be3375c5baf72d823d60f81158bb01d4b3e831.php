

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('auth_body'); ?>
<div class="container">
    <div class="col-md-12">
        <div class="tab">
            <div class="row">
                <h6 class="input-group mb-12">Bienvenido, <?php echo e(Auth::user()->name); ?></h6>
                <hr>
                <p><span class="badge badge-light">Por favor seleccione Sucursal y Punto Venta</span></p>
            </div>
            <form method="POST" action="<?php echo e(url('/guardarUbicacion')); ?>" accept-charset="UTF-8" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-4">
                    <select id="agencia_id" name="agencia_id" class="form-control" onchange="cargarPuntosVentas()" required>
                        <option value="">Seleccione una Sucursal</option>
                        <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-group mb-4">
                    <select id="punto_venta_id" name="punto_venta_id" class="form-control" required>
                        <option value="">Seleccione un Punto de Venta</option>
                    </select>
                </div>
                <div class="input-group mb-4">                   
                    <button type="submit" class="btn btn-success">Ingresar</button>                    
                </div>
            </form>            
        </div>            
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    function cargarPuntosVentas()
    {
        var formData = { agencia: $('#agencia_id').val() };        
        $.ajax({
            url: "<?php echo e(url('/cargarPuntosVentaU')); ?>",
            type: "GET",
            data: formData,
            dataType: 'json',
            success: function(data) {
                $('#punto_venta_id').empty();
                $('#punto_venta_id').append('<option value="">Seleccione un Punto de Venta</option>');
                $.each(data, function(key, value) {
                    $('#punto_venta_id').append('<option value="'+ value.id +'">'+ value.nombre +'</option>');
                });
            },
            error: function(data) {
                if (data.status == 409) {
                    swal.fire('Error', JSON.parse(data.responseText).mensaje, 'error');                                        
                } else {
                    swal.fire('Error', 'Ocurrió un error al cargar los puntos de venta.', 'error');
                }                
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::auth.auth-page', ['auth_type' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/auth/loginUbicacion.blade.php ENDPATH**/ ?>