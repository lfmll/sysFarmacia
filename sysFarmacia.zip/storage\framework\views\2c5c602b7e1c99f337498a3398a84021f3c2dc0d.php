

<?php $__env->startSection('title', 'Laboratorios'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-6">   
        <div class="card card-success"> 
            <div class="card-header with-border">
                <h3 class="card-title"><i class="fas fa-fw fa-flask"></i> Editar Laboratorio</h3>                
            </div> 
            
            <?php echo $__env->make('laboratorio.form',['laboratorio'=>$laboratorio,'url'=>'/laboratorio/'.$laboratorio->id,'method'=>'PATCH'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            
            
        </div>            
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/laboratorio/edit.blade.php ENDPATH**/ ?>