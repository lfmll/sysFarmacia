<?php echo Form::open(['url'=>'/cliente/'.$cli->id, 'method'=>'DELETE', 'class'=> 'd-inline-block']); ?>

<a class="btn btn-danger btn-sm eliminar"><i class="fa fa-trash"></i> Eliminar</a>
<?php echo Form::close(); ?>


<?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/cliente/delete.blade.php ENDPATH**/ ?>