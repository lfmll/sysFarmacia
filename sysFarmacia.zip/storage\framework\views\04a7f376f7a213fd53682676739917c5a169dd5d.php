

<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Sistema Farmacia</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido.</p>
    
      <canvas id="myChart" style="width: 100%; max-width:700px"></canvas>  
      
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script> console.log('Hi!'); </script>
    <script>
        
        var labels =<?php echo e(Illuminate\Support\Js::from($labels)); ?>;
        
        var datas=<?php echo e(Illuminate\Support\Js::from($datas)); ?>;

        const ctx = document.getElementById('myChart');
      
        new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            backgroundColor: 'rgb(255, 99, 132)',
            datasets: [{
              label: '# de Ventas por Mes',
              fill: true,
              lineTension: 0,
              data: datas,
              borderWidth: 1              
            }]
          },
          responsive: true, 
          options:{
            scales:{
              y:{
                min:0,
                ticks:{
                  stepSize:1
                }
              }
            }
          }
        });
      </script>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/admin/home.blade.php ENDPATH**/ ?>