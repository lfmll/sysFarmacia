<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
    </style>
    <title>Reporte de Lotes</title>
</head>
<body>
    <header>
        <h2 style="text-align:center">Lista de Lotes en Vencimiento</h2>
        <h3 style="text-align:center"><?php echo e($fecha); ?></h3>
    </header>
    <main>
        <p><strong>Lotes por Vencer</strong></p>
        <table width="100%">
            <thead>
                <tr>
                    <th>No</th>                
                    <th>Cod. Lote</th>
                    <th>Producto</th>
                    <th>Laboratorio</th>
                    <th>Fecha Vencimiento</th>
                    <th>Cantidad</th>                                        
                    <th>Precio Compra</th>
                    <th>Precio Venta</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lotesPorVencer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lotep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($lotep->numero); ?></td>
                    <?php if(!is_null($lotep->medicamento)): ?>
                        <td>
                            <?php echo e($lotep->medicamento->nombre_comercial); ?>

                        </td>
                    <?php endif; ?>
                    <?php if(!is_null($lotep->insumo)): ?>
                        <td>
                            <?php echo e($lotep->insumo->nombre); ?>

                        </td>
                    <?php endif; ?>
                    <td><?php echo e($lotep->laboratorio->nombre); ?></td>
                    <td><?php echo e($lotep->fecha_vencimiento); ?></td>
                    <td><?php echo e($lotep->cantidad); ?></td>
                    <td><?php echo e($lotep->precio_compra); ?></td>
                    <td><?php echo e($lotep->precio_venta); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <hr>
        <p><strong>Lotes Vencidos</strong></p>
        <table width="100%">
            <thead>
                <tr>
                    <th>No</th>                
                    <th>Cod. Lote</th>
                    <th>Producto</th>
                    <th>Laboratorio</th>
                    <th>Fecha Vencimiento</th>
                    <th>Cantidad</th>                                        
                    <th>Precio Compra</th>
                    <th>Precio Venta</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lotesVencidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lotev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($lotev->numero); ?></td>
                    <?php if(!is_null($lotev->medicamento)): ?>
                        <td><?php echo e($lotev->medicamento->nombre_comercial); ?></td>
                    <?php endif; ?>
                    <?php if(!is_null($lotev->insumo)): ?>
                        <td><?php echo e($lotev->insumo->nombre); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($lotev->laboratorio->nombre); ?></td>
                    <td><?php echo e($lotev->fecha_vencimiento); ?></td>
                    <td><?php echo e($lotev->cantidad); ?></td>
                    <td><?php echo e($lotev->precio_compra); ?></td>
                    <td><?php echo e($lotev->precio_venta); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </main>
    <hr>
    <footer>
        <p style="text-align:right">Fecha de Impresión: <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i')); ?></p>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/lote/reporteLotesVencimiento.blade.php ENDPATH**/ ?>