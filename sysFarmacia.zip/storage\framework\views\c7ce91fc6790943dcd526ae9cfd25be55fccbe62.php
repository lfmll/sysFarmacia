

<?php $__env->startSection('title', 'PuntoVenta'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Punto de Venta</h3>                                                    
            </div>
            <div class="card-body">
                <div class="dataTables_wrapper dt-bootstrap4">
                    <table id="tagente" class="table table-bordered">
                        <thead>
                            <tr>                            
                                <th>Código</th>    
                                <th>Nombre</th>            
                                <th>Sucursal</th>
                                <th>Empleado</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $puntoventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puntoventa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($puntoventa->codigo); ?></td>
                                <td><?php echo e($puntoventa->nombre); ?></td>
                                <td><?php echo e($puntoventa->agencia->nombre); ?></td>
                                <td><?php echo e($puntoventa->usuario); ?></td>
                                <td>
                                    <?php echo $__env->make('puntoventa.delete',['puntoventa'=>$puntoventa], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                      
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(url('/puntoventa/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nuevo</a>
            </div>
        </div>    
    </div>    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        $(document).on('click', '.eliminar', function(e){
            e.preventDefault();
            const form = $(this).closest('form');
            const nombre = $(this).data('nombre');

            Swal.fire({
                title: '¿Está seguro de cerrar el Punto de Venta?',
                text: "Punto de Venta: "+ nombre,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, eliminar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();            
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/puntoventa/index.blade.php ENDPATH**/ ?>