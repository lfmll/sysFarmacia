<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
    </style>
    <title>Reporte de Ventas</title>
</head>
<body>
    <header>
        <h2 style="text-align:center">Lista de Ventas del Día</h2>
        <h3 style="text-align:center"><?php echo e($fecha); ?></h3>
    </header>
    <main>
        <table width="100%">
            <thead>
                <tr>
                    <th>No</th>                
                    <th>Comprobante</th>
                    <th>Forma de Pago</th>
                    <th>Total</th>
                    <th>Glosa</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($venta->comprobante); ?></td>
                    <td><?php echo e($venta->forma_pago); ?></td>
                    <td><?php echo e($venta->pago_venta - $venta->cambio_venta); ?></td>
                    <td><?php echo e($venta->glosa); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>
    <hr>
    <footer>
        
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/venta/reporteVentaDia.blade.php ENDPATH**/ ?>