

<?php ( $login_url = View::getSection('login_url') ?? config('adminlte.login_url', 'login') ); ?>
<?php ( $register_url = View::getSection('register_url') ?? config('adminlte.register_url', 'register') ); ?>

<?php if(config('adminlte.use_route_url', false)): ?>
    <?php ( $login_url = $login_url ? route($login_url) : '' ); ?>
    <?php ( $register_url = $register_url ? route($register_url) : '' ); ?>
<?php else: ?>
    <?php ( $login_url = $login_url ? url($login_url) : '' ); ?>
    <?php ( $register_url = $register_url ? url($register_url) : '' ); ?>
<?php endif; ?>

<?php $__env->startSection('auth_header', __('adminlte::adminlte.register_message')); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('auth_body'); ?>
    <form action="<?php echo e($register_url); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        
        <div class="input-group mb-3">
            <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>"
                   value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(__('adminlte::adminlte.full_name')); ?>" autofocus>
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-user <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('name')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="input-group mb-3">
            <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
                   value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(__('adminlte::adminlte.email')); ?>">
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-envelope <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('email')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="input-group mb-3">
            <input type="password" name="password"
                   class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>"
                   placeholder="<?php echo e(__('adminlte::adminlte.password')); ?>">
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-lock <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('password')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="input-group mb-3">
            <input type="password" name="password_confirmation"
                   class="form-control <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>"
                   placeholder="<?php echo e(__('adminlte::adminlte.retype_password')); ?>">
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-lock <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('password_confirmation')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="input-group mb-3">
            <select name="agencia" id="agencia" onchange="cargarPuntosVentaP()" required class="form-control <?php echo e($errors->has('agencia') ? 'is-invalid' : ''); ?>">
                <option value="" disabled selected>Seleccione una Sucursal</option>
                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-building <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('agencia')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('agencia')); ?></strong>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="input-group mb-3">
            <select name="punto_venta" id="puntosVentas" class="form-control <?php echo e($errors->has('punto_venta') ? 'is-invalid' : ''); ?>">
                <option value="" disabled selected>Seleccione un Punto de Venta</option>                
                {-- Los puntos de venta se cargarán dinámicamente mediante JavaScript basado en la agencia seleccionada --}
            </select>
            <div class="input-group-append">
                <div class="input-group-text">
                    <span class="fas fa-store <?php echo e(config('adminlte.classes_auth_icon', '')); ?>"></span>
                </div>
            </div>
            <?php if($errors->has('punto_venta')): ?>
                <div class="invalid-feedback">
                    <strong><?php echo e($errors->first('punto_venta')); ?></strong>
                </div>
            <?php endif; ?>
        </div>
        
        <button type="submit" class="btn btn-block <?php echo e(config('adminlte.classes_auth_btn', 'btn-flat btn-primary')); ?>">
            <span class="fas fa-user-plus"></span>
            <?php echo e(__('adminlte::adminlte.register')); ?>

        </button>

    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth_footer'); ?>
    <p class="my-0">
        <a href="<?php echo e($login_url); ?>">
            <?php echo e(__('adminlte::adminlte.i_already_have_a_membership')); ?>

        </a>
    </p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>
<script>
    function cargarPuntosVentaP()
    {
        var formData = { agencia: $('#agencia').val() };   
        console.log(formData);     
        $.ajax({
            url: "<?php echo e(url('/cargarPuntosVentaP')); ?>",
            type: "GET",
            data: formData,
            dataType: 'json',
            success: function(data) {
                $('#puntosVentas').empty();
                $('#puntosVentas').append('<option value="">Seleccione un Punto de Venta</option>');
                $.each(data, function(key, value) {
                    $('#puntosVentas').append('<option value="'+ value.id +'">'+ value.nombre +'</option>');
                });
            },
            error: function(data) {
                console.log(data);
                if (data.status == 409) {
                    swal.fire('Error', JSON.parse(data.responseText).mensaje, 'error');                                        
                } else {
                    swal.fire('Error', 'Ocurrió un error al cargar los puntos de venta.', 'error');
                }                
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.auth-page', ['auth_type' => 'register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/vendor/adminlte/auth/register.blade.php ENDPATH**/ ?>