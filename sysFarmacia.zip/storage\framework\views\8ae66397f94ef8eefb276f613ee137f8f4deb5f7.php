

<?php $__env->startSection('title', 'Medicamento'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-sm-6">
        <div class="card card-primary">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-10">
                        <h1 class="card-title"><?php echo e($medicamento->codigo_producto); ?></h1>
                    </div>
                    <div class="col-sm-2">
                        <a href="<?php echo e(url('/detalleMedicamento/'.$medicamento->id)); ?>" class="btn btn-primary"><i class="fa fa-print"></i> Imprimir</a>
                    </div>                                        
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <li class="list-group-item list-group-item-primary"><?php echo e($medicamento->nombre_comercial); ?> - <?php echo e($medicamento->nombre_generico); ?></li>
                    </div>
                </div>
                <hr style="border: none;"> 
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item list-group-item-primary">Composición:</li>
                            <li class="list-group-item disabled"><?php echo e($medicamento->composicion); ?></li>
                        </ul>                        
                    </div>
                    <div class="col-md-6">
                        <li class="list-group-item list-group-item-primary">Observación:</li>
                        <li class="list-group-item disabled"><?php echo e($medicamento->observacion); ?></li>
                    </div>
                </div>  
                <hr style="border: none;">                               
                <div class="row">
                    <div class="col-md-6">
                        <li class="list-group-item list-group-item-primary">Indicación:</li>
                        <li class="list-group-item disabled"><?php echo e($medicamento->indicacion); ?></li>
                    </div>
                    <div class="col-md-6">
                        <li class="list-group-item list-group-item-primary">Contra-Indicación:</li>
                        <li class="list-group-item disabled"><?php echo e($medicamento->contraindicacion); ?></li>                    
                    </div>                                        
                </div>
                <hr>                    
                <div class="row">
                    <div class="col-md-3">
                        <ul class="list-group">
                            <li class="list-group-item list-group-item-primary">Unidad Medida:</li>
                            <li class="list-group-item disabled"><?php echo e($unidad_medida->descripcion); ?></li>
                        </ul> 
                    </div>
               
                    <div class="col-md-3">
                        <ul class="list-group">
                            <li class="list-group-item list-group-item-primary">Vía Administración:</li>
                            <?php if(!is_null($vias)): ?>
                            <li class="list-group-item disabled"><?php echo e($vias->descripcion); ?></li>
                            <?php endif; ?>
                        </ul>                        
                    </div>
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item list-group-item-primary">Acciones Terapéuticas:</li>
                            <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item disabled"><?php echo e($cl->nombre); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </ul>  
                    </div> 
                </div>
                <hr >
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item list-group-item-primary">Dosis:</li>
                            <?php if(!is_null($medidamedicamento1)): ?>
                            <li class="list-group-item disabled">Lactantes: <?php echo e($medidamedicamento1); ?> <br> <?php echo e($dosis_estandar1); ?></li>
                            <?php endif; ?>
                            <?php if(!is_null($medidamedicamento2)): ?>
                            <li class="list-group-item disabled">Infantes:  <?php echo e($medidamedicamento2); ?> <br> <?php echo e($dosis_estandar2); ?></li>
                            <?php endif; ?>
                            <?php if(!is_null($medidamedicamento3)): ?>
                            <li class="list-group-item disabled">Adultos:   <?php echo e($medidamedicamento3); ?> <br> <?php echo e($dosis_estandar3); ?></li>
                            <?php endif; ?>
                        </ul>  
                    </div>
                                       
                </div>                   
            </div>                         
            <div class="card-footer">
                <h5>Stock:</h5>
                <span>   
                    <?php echo e($medicamento->stock); ?>

                </span> 
            </div>
        </div>                
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/medicamento/show.blade.php ENDPATH**/ ?>