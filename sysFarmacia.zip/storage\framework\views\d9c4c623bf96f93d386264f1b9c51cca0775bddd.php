

<?php $__env->startSection('title', 'Laboratorio'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-success">
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-4">                            
                            <a href="<?php echo e(url('#')); ?>" class="btn btn-success"><i class="fa fa-flask fa-lg"></i></a>
                        </div>
                        <div class="col-sm-6">
                            <h5>Laboratorios</h5>
                        </div>
                        <div class="col-sm-2">
                            <a href="<?php echo e(url('listaLaboratorios')); ?>" class="btn btn-success"><i class="fa fa-print"></i> Imprimir</a>
                        </div>    
                                      
                    </div>                    
                </div>
                <div class="card-body">
                    <div class="dataTables_wrapper dt-bootstrap4">
                        <table id="tlaboratorio" class="table table-bordered">
                            <thead>
                                <tr>
                                    <td>ID</td>                
                                    <td>Nombre</td>
                                    <td>Dirección</td>
                                    <td>Teléfono</td>
                                    <td>Procedencia</td>
                                    <td>Anotaciones</td>
                                    <td>Acciones</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $laboratorio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($lab->id); ?></td>
                                    <td><?php echo e($lab->nombre); ?></td>
                                    <td><?php echo e($lab->direccion); ?></td>
                                    <td><?php echo e($lab->telefono); ?></td>
                                    <td><?php echo e($lab->procedencia); ?></td>
                                    <td><?php echo e($lab->anotacion); ?></td>
                                    <td>
                                    <a href="<?php echo e(url('/laboratorio/'.$lab->id.'/edit')); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Editar</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>                                      
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(url('/laboratorio/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nuevo</a>
                </div>
            </div>    
        </div>    
    </div>        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tlaboratorio').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [4, 8, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/laboratorio/index.blade.php ENDPATH**/ ?>