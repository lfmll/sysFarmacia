

<?php $__env->startSection('title', 'Compras'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Compras</h3>                                                    
            </div>
            <div class="card-body">
                <div class="dataTables_wrapper dt-bootstrap4">
                    <table id="tcompras" class="table table-bordered">
                        <thead>
                            <tr>                                
                                <td>Comprobante</td>
                                <td>Fecha Compra</td>            
                                <td>Proveedor</td> 
                                <td>Forma Pago</td> 
                                <td>Total</td>    
                                <td>Glosa</td>                          
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>                                
                                <td><?php echo e($compra->comprobante); ?></td>
                                <td><?php echo e($compra->fecha_compra); ?></td>
                                <?php if(is_null($compra->agente)): ?>
                                    <td></td>
                                <?php else: ?>
                                    <td><?php echo e($compra->agente->nombre); ?><br><?php echo e($compra->agente->telefonos); ?></td>
                                <?php endif; ?>   
                                <td><?php echo e($compra->forma_pago); ?></td>
                                <td><?php echo e($compra->pago_compra - $compra->cambio_compra); ?></td>
                                <?php if(is_null($compra->glosa)): ?> 
                                    <td></td>
                                    <td>                                
                                        <a href="<?php echo e(url('/compra/'.$compra->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-bars"></i> Detalle</a>
                                    </td>
                                <?php else: ?>
                                    <td><?php echo e($compra->glosa); ?></td>
                                    <td></td>
                                <?php endif; ?>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                      
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(url('/compra/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nueva Compra</a>
            </div>
        </div>    
    </div>    
</div>
        

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tcompras').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [4, 8, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/compra/index.blade.php ENDPATH**/ ?>