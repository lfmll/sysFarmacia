

<?php $__env->startSection('title', 'Presentaciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-info">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-4">                            
                        <a href="<?php echo e(url('#')); ?>" class="btn btn-info"><i class="fa fa-pills fa-lg"></i></a>
                    </div>
                    <div class="col-sm-8">
                        <h5>Presentaciones</h5>
                    </div>
                </div>
            </div>            
            <div class="card-body">
                <div class="dataTables_wrapper dt-bootstrap4">
                    <table id="tformato" class="table table-bordered">
                        <thead>
                            <tr>
                                <td>ID</td>            
                                <td>Descripción</td>
                                <td>Modificar</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $formato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($f->id); ?></td>
                                <td><?php echo e($f->descripcion); ?></td>
                                <td>
                                <a href="<?php echo e(url('/formato/'.$f->id.'/edit')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Editar</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                      
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(url('/formato/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nuevo</a>
            </div>
        </div>    
    </div>    
</div>
        

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tformato').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [4, 8, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/formato/index.blade.php ENDPATH**/ ?>