
<?php $__env->startSection('title', 'Nota de Ajuste'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <?php echo Form::open(['url' => '/notaAjuste', 'method' => 'POST']); ?>

            <?php echo csrf_field(); ?>
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-fw fa-file-alt"></i>Crear Nota de Ajuste para la Factura #<?php echo e($factura->id); ?></h3>
            </div>
        </div>
        <div class="card-body">            
            <input type="hidden" name="factura_id" value="<?php echo e($factura->id); ?>">
            <div class="row">
                <div class="form-group col-sm-6">
                    <label for="tipoNota">Tipo de Nota</label>
                    <select name="tipoNota" id="tipoNota" class="form-control" required>
                        <option value="1">Débito</option>
                        <option value="2">Crédito</option>
                    </select>
                </div>
                <div class="form-group col-sm-6">
                    <label for="motivo">Motivo</label>
                    <select name="motivo" id="motivo" class="form-control" required>
                        <option value="Devolución">Devolución</option>
                        <option value="Recargo">Recargo</option>
                        <option value="Corrección">Corrección</option>                        
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-sm-12">
                    <label for="Factura">Datos Factura Original</label>
                </div>
            </div>   
            <div class="row">
                <div class="form-group col-sm-2">
                    <label for="nroFactura">No. Factura</label>
                    <input type="text" class="form-control" value="<?php echo e($factura->numeroFactura); ?>" disabled>
                </div>
                <div class="form-group col-sm-2">
                        <label for="Fecha">Fecha Emisión</label>
                        <input type="text" class="form-control" value="<?php echo e($factura->fechaEmision); ?>" disabled>
                    </div>
                <div class="form-group col-sm-4">
                    <label for="nroAutorizacion">No. Autorización</label>
                    <input type="text" class="form-control" value="<?php echo e($factura->cuf); ?>" disabled>
                </div>
                <div class="form-group col-sm-4">
                    <label for="codigoControl">Código Control</label>
                    <input type="text" class="form-control" value="<?php echo e($factura->codigoRecepcion); ?>" disabled>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-sm-12">
                    <label for="DetalleFactura">Datos Detalle Factura Original</label>
                </div>                    
            </div>
            <div class="row">
                <table id="tdetalleFactura" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Descuento</th>
                            <th>SubTotal</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detalleFactura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr> 
                                <td>
                                    <input type="hidden" name="dmodificado[<?php echo e($detalle->id); ?>]" id="dmodificadoHidden<?php echo e($detalle->id); ?>" value="0">
                                    <input type="checkbox" id="dmodificado<?php echo e($detalle->id); ?>" name="dmodificado[]" disabled>
                                </td>                                   
                                <td><?php echo e($detalle->descripcion); ?></td>
                                <td><input type="number" id="dcantidad<?php echo e($detalle->id); ?>" name="dcantidad[]" class="form-control" value="<?php echo e($detalle->cantidad); ?>" min="1" step="1" onchange="cambiarImporte('<?php echo e($detalle->id); ?>');" data-original="<?php echo e($detalle->cantidad); ?>"></td>                                    
                                <td><input type="number" id="dprecio<?php echo e($detalle->id); ?>" name="dprecio[]" class="form-control" value="<?php echo e($detalle->precioUnitario); ?>" min="0" step="0.01" onchange="cambiarImporte('<?php echo e($detalle->id); ?>');" data-original="<?php echo e($detalle->precioUnitario); ?>"></td>
                                <td><input type="number" id="ddescuento<?php echo e($detalle->id); ?>" name="ddescuento[]" class="form-control" value="<?php echo e($detalle->descuento ?? 0); ?>" min="0" step="0.01" onchange="cambiarImporte('<?php echo e($detalle->id); ?>');" data-original="<?php echo e($detalle->descuento); ?>"></td>       
                                <td><input type="number" id="dsubtotal<?php echo e($detalle->id); ?>" name="dsubtotal[]" class="form-control" value="<?php echo e($detalle->subTotal); ?>"  min="0" readonly></td>                                    
                            </tr>                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" style="text-align: right;"><strong>Monto Subtotal:</strong></td>
                            <td colspan="1">
                                <input type="number" id="eSubtotal" name="eSubtotal" class="form-control" value="<?php echo e($totalSubTotal); ?>" readonly>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5" style="text-align: right;"><strong>Monto Descuento Crédito Débito:</strong></td>
                            <td colspan="1">
                                <input type="number" id="eDescuento" name="eDescuento" class="form-control" value="0" min="0" step="0.01" onchange="descontarTotal(this.value);">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5" style="text-align: right;"><strong>Total:</strong></td>
                            <td colspan="1">
                                <input type="number" id="eTotal" name="eTotal" class="form-control" value="<?php echo e($factura->montoTotal); ?>" readonly>                                    
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>            
        </div>
        <div class="card-footer">
            <div class="form-group">
                <div class="float-left">
                    <a type="submit" class="btn btn-default btn-lg" href="<?php echo e(url('/factura')); ?>">Cancelar</a>    
                </div>
                <div class="float-right">
                    <button type="submit" class="btn btn-success btn-lg">Guardar</button>  
                </div>            
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>   
<?php $__env->startSection('js'); ?>
<script>
    function cambiarImporte(index) {
        const cantidadInput = document.getElementById('dcantidad' + index);
        const precioInput = document.getElementById('dprecio' + index);
        const descuentoInput = document.getElementById('ddescuento' + index);
        const subtotalInput = document.getElementById('dsubtotal' + index);
        const subtotalSumaInput = document.getElementById('eSubtotal');
        const totalInput = document.getElementById('eTotal');
        
        //Valores Actuales
        const cant = parseFloat(cantidadInput.value) || 0;
        const precio = parseFloat(precioInput.value) || 0;
        const descuento = parseFloat(descuentoInput.value) || 0;

        //Valores Originales
        const cantOriginal = parseFloat(cantidadInput.dataset.original) || 0;
        const precioOriginal = parseFloat(precioInput.dataset.original) || 0;
        const descuentoOriginal = parseFloat(descuentoInput.dataset.original) || 0;
        
        if (precio < 0 || cant <= 0) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Valor inválido',
            });
            precioInput.value = 0;
            return;
        }

        const subtotal = (cant * precio) - descuento;
        subtotalInput.value = subtotal.toFixed(2);

        let total = 0;
        document.querySelectorAll('input[name="dsubtotal[]"]').forEach((input) => {
            total += parseFloat(input.value) || 0;
        });
        total = total.toFixed(2);
        subtotalSumaInput.value = total;
        totalInput.value = total;

        const modificado = cant !== cantOriginal || precio !== precioOriginal || descuento !== descuentoOriginal;
        
        document.getElementById('dmodificado'+index).checked = modificado;
        document.getElementById('dmodificadoHidden'+index).value = modificado ? 1 : 0;
    }

    function descontarTotal(val){
        sub = document.getElementById('eSubtotal').value;
        if (val > sub){
            Swal.fire({
                icon: "error",
                title: "Alerta",
                text: "El descuento no puede exceder el Subtotal"
            });
            return;
        }
        total = parseFloat(sub) - parseFloat(val);
        total = total.toFixed(2);
        document.getElementById("eTotal").value = total;
    }
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/notaAjuste/create.blade.php ENDPATH**/ ?>