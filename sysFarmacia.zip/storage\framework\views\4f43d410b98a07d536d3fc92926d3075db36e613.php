
<?php $__env->startSection('title', 'Crear Evento'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['url'=>'/evento','method'=>'POST']); ?>

    <?php echo e(Form::token()); ?>

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Crear Evento</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('tipo', 'Tipo del Evento'); ?>

                        <?php echo Form::select('tipos', $eventos, null, ['class' => 'form-control', 'placeholder' => 'Seleccione un motivo']); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('cafc', 'CAFC'); ?>

                        <?php echo Form::text('cafc', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el cafc del evento']); ?>    
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('fecha', 'Fecha'); ?>

                        <?php echo Form::date('fecha', $fecha, ['class' => 'form-control', 'readonly']); ?>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <?php echo Form::label('hora', 'Hora'); ?>

                        <?php echo Form::time('hora', $hora, ['class' => 'form-control', 'readonly']); ?>

                    </div>
                </div>
            </div>
            <div class="form-group">
                <?php echo Form::label('nombre', 'Nombre del Evento'); ?>

                <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' => 'Ingrese el nombre del evento', 'required', 'readonly']); ?>

            </div>           
        </div>
        <div class="card-footer">
            <div class="form-group">
                <div class="float-left">
                    <a href="<?php echo e(url('/evento')); ?>" class="btn btn-secondary">Cancelar</a>
                </div>
                <div class="float-right">
                    <?php echo Form::submit('Guardar Evento', ['class' => 'btn btn-success']); ?>

                </div>
            </div>                        
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/evento/create.blade.php ENDPATH**/ ?>