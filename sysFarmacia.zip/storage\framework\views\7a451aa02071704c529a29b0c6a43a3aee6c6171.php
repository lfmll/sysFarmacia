<?php echo Form::open(['url' => url('/puntoventa/' . $puntoventa->id), 'method' => 'DELETE', 'class' => 'd-inline-block']); ?>

<button type="button" class="btn btn-danger btn-sm eliminar" data-nombre="<?php echo e($puntoventa->nombre); ?>">
    <i class="fa fa-trash"></i> Eliminar
</button>
<?php echo Form::close(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/puntoventa/delete.blade.php ENDPATH**/ ?>