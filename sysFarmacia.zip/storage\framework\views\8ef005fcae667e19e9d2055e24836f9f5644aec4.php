<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        h4{margin:0;}
        table, th, td {
            table-layout: auto;
            word-wrap:break-word;      
            font-size: 8px;			
        }

        hr{
            width: 90%;
            margin-left: auto; 
            margin-right: auto;
        }

        table.detalle, .leyenda{
            border-collapse: collapse;
            table-layout: auto;
            margin-left: auto; 
            margin-right: auto; 
            width: 90%;
        }

        table.detalle td {
            border-bottom: 0.5px solid;
        } 

		body {
			margin: 0;
            padding: 0;
		}

		@page  {
            height: auto;
            margin-top: 0cm;
            margin-left: 0cm;
            margin-right: 0cm;
        }
    </style>
    <title>Factura</title>
</head>
<body>
    <table width="100%">
        <tr>
            <td colspan="4" style="text-align: center;"><h2>FACTURA</h2></td>            
        </tr>
		<tr>
			<td colspan="4" style="text-align: center;">
				<?php if($factura->codigoSucursal==0): ?>
					<h4>Casa Matriz</h4>
				<?php else: ?>
					<h4>Sucursal <?php echo e($factura->codigoSucursal); ?></h4>
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<td colspan="4" style="text-align: center;"><?php echo e($factura->direccion); ?></td>
		</tr>
        <tr>
            <td colspan="4" style="text-align: center;"><?php echo e($factura->municipio); ?> - Bolivia</td>
        </tr>
    </table>
    <hr>
    <table width="100%">
        <tr>
            <td colspan="4" style="text-align: center;">NIT: <?php echo e($factura->nitEmisor); ?></td>                                    
        </tr>			
		<tr>
			<td colspan="4" style="text-align: center;">FACTURA N: <?php echo e($factura->numeroFactura); ?></td>
		</tr>
        <tr>             
            <td colspan="4" style="text-align: center;"><h4>COD. AUTORIZACION</h4></td>
        </tr>
		<tr>
			<td colspan="4" style="text-align: center;"><h4><?php echo e($factura->cuf); ?></h4></td>
		</tr>
        <tr>
            <td colspan="4" style="text-align: center;"><h4>Nombre/Razón Social: <?php echo e($factura->nombreRazonSocialEmisor); ?></h4></td> 
        </tr>        
    </table>   
    <hr>
    <table style="width: 100%">
        <tr>
            <td colspan="4" style="text-align: center;"><h4>NIT/CI/CEX: <?php echo e($factura->numeroDocumento); ?></h4></td>            
        </tr>
        <tr>
            <td colspan="4" style="text-align: center;"><h4><?php echo e($factura->nombreRazonSocial); ?></h4></td>
        </tr>
        <tr><td colspan="4" style="text-align: center;">Fecha: <?php echo e($factura->fechaEmision); ?></td></tr>       
    </table>
    <hr>
    <table class="detalle">
        <thead>
            <tr style="border-bottom: 1px solid;">
                <th style="text-align: left">PRODUCTO</th>
                <th style="text-align: right">CANTIDAD</th>
                <th style="text-align: right">P/U</th>
                <th style="text-align: right">SUBTOTAL</th>
            </tr>            
        </thead>
        <tbody style="border-bottom: 1px solid;">
        <?php $__currentLoopData = $detalleFactura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($item->descripcion); ?></td>
            <td style="text-align: right"><?php echo e($item->cantidad); ?></td>
            <td style="text-align: right"><?php echo e($item->precioUnitario); ?></td>
            <td style="text-align: right"><?php echo e($item->subTotal); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align: right">TOTAL</td>
                <td style="border: 0.5px; text-align: right"><?php echo e($venta->total); ?></td>
            </tr>                     
            <?php if($venta->descuento > 0): ?>
            <tr>
                <td colspan="3" style="text-align: right">DESCUENTO</td>
                <td style="border: 0.5px; text-align: right"><?php echo e($venta->descuento); ?></td>
            </tr>            
            <?php endif; ?>
            <tr>
                <td colspan="3" style="text-align: right">MONTO</td>
                <td style="border: 0.5px; text-align: right"><?php echo e($venta->monto_pagar); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: right">CAMBIO</td>
                <td style="border: 0.5px; text-align: right"><?php echo e($venta->cambio_venta); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: right">IMPORTE BASE CREDITO FISCAL</td>
                <td style="border: 0.5px; text-align: right"><?php echo e($venta->importe_iva); ?></td>
            </tr>            
        </tfoot>
    </table>
    <br>
    <table class="leyenda">
        <tr>
            <td colspan="4" style="text-align: center;">
                "ESTA FACTURA CONTRIBUYE AL DESARROLLO DE NUESTRO PAÍS, EL USO ILÍCITO DE ÉSTA SERÁ SANCIONADO DE ACUERDO A LEY"
            </td>            
        </tr>
        <tr>
            <td colspan="4" style="text-align: center;"><?php echo e($factura->leyenda); ?></td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/factura/factura_rollo.blade.php ENDPATH**/ ?>