<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
    </style>
    <title>Reporte de Laboratorios</title>
</head>
<body>
    <header>
        <h2 style="text-align:center">Listado de Laboratorios</h2>
    </header>
    <main>
        <table width="100%">
            <thead>
                <tr>
                    <th>No</th>                
                    <th>Nombre</th>
                    <th>Dirección</th>
                    <th>Teléfono</th>
                    <th>Procedencia</th>
                    <th>Anotaciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $laboratorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laboratorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($laboratorio->nombre); ?></td>
                    <td><?php echo e($laboratorio->direccion); ?></td>
                    <td><?php echo e($laboratorio->telefono); ?></td>
                    <td><?php echo e($laboratorio->procedencia); ?></td>
                    <td><?php echo e($laboratorio->anotacion); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>
    <hr>
    <footer>
        <h3 style="text-align:right"><?php echo e($fecha); ?></h3>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/laboratorio/reporte.blade.php ENDPATH**/ ?>