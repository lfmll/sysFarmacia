<?php echo Form::open(['url' => $url, 'method' => $method, 'files' => true]); ?> 
<div class="card-body">    
    <div class="form-group">
        <?php echo e(Form::label('nro', 'Nombre Sucursal')); ?>

        <?php echo e(Form::text('nombre',$agencia->nombre,['class'=>'form-control', 'placeholder'=>'Nombre de Sucursal','required'])); ?>

    </div> 
    <div class="form-group">
            <?php echo e(Form::label('direccion','Direccion')); ?>

            <?php echo e(Form::text('direccion',$agencia->direccion,['class'=>'form-control', 'placeholder'=>'Direccion','required'])); ?>

    </div> 
    <div class="form-group">
            <?php echo e(Form::label('telefono', 'Telefono')); ?>

            <?php echo e(Form::number('telefono',$agencia->telefono,['class'=>'form-control','placeholder'=>0, 'min'=>'0'])); ?>

    </div>
    <div class="form-group">        
            <?php echo e(Form::label('departamento', 'Departamento')); ?>

            <?php echo Form::select('departamento', ['Santa Cruz'=>'Santa Cruz',
                                        'La Paz'=>'La Paz',
                                        'Cochabamba'=>'Cochabamba',
                                        'Chuquisaca'=>'Chuquisaca',
                                        'Tarija'=>'Tarija',
                                        'Oruro'=>'Oruro',
                                        'Potosi'=>'Potosi',
                                        'Beni'=>'Beni',
                                        'Pando'=>'Pando'], 
                                        $agencia->departamento,                                            
            ['class'=>'form-control','placeholder'=>'Departamento','required']); ?>

    </div>
    <div class="form-group">
        <?php echo e(Form::label('municipio', 'Municipio')); ?>

        <?php echo e(Form::text('municipio',$agencia->municipio,['class'=>'form-control', 'placeholder'=>'Municipio','required'])); ?>

    </div>       
</div>    
<div class="card-footer">
    <div class="float-left">
        <a type="submit" class="btn btn-default" href="<?php echo e(url('/cliente')); ?>">Cancelar</a>    
    </div>   
    <div class="float-right">
    <?php echo $__env->yieldContent('aceptar'); ?>
        <input type="submit" value="Guardar" class="btn btn-info">
    </div>
</div>
<?php echo Form::close(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/agencia/form.blade.php ENDPATH**/ ?>