

<?php $__env->startSection('title', 'Factura'); ?>

<?php $__env->startSection('content'); ?>
<header>
    <div>
        <div style="text-align: center; font-size: 13px; text-transform: uppercase;">
            <?php echo e($sucursal); ?><br>
            <?php echo e($direccion); ?><br>
            TELEFONO - <?php echo e($telefono); ?><br>
            Santa Cruz - Bolivia
        </div>
        <div>
            <h4 id="factura">FACTURA</h4>
        </div>
        <div id="datosfactura">
            <div>
                <span><strong>NIT:</strong></span><?php echo e($facturanit); ?>

            </div>
            <div>
                <span><strong>Nº FACTURA:</strong></span><?php echo e($nroFactura); ?>

            </div>
            <div>
                <span><strong>Nº AUTORIZACION:</strong></span><?php echo e($nroAutorizacion); ?>

            </div>
        </div>
        <div id="descripcion">
            <p><?php echo e($actividad); ?></p>
        </div>
    </div>
    <div id="project">
        <div>
            <span>
                <strong>Fecha:</strong><?php echo e($fecha); ?>

                
            </span>
        </div> 
        <div>
            <span><strong>NIT/CI:</strong></span> <?php echo e($facturanit); ?>

        </div>
        <div>
            <span><strong>Señor(es):</strong></span> <?php echo e($razonSocial); ?>

        </div>
    </div>
</header>
<main>
    <div id="detalleVenta">
        <table>
            <thead class="encabezado">
                <tr>
                    <th> CANTIDAD</th>
                    <th class="desc"> DETALLE </th>
                    <th> P.UNITARIO </th>
                    <th> SUBTOTAL </th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>
        <div id="total">
            <div>
                <p>
                    <strong>TOTAL Bs. </strong>
                </p>
            </div>
            
            <div>
                <p>
                    <strong>TOTAL NETO Bs. </strong>
                </p>
            </div>
        </div>
    </div>
    <div id="totLiteral">
        <span>SON: </span>
    </div>
    <div id="notices">
        <div class="notice">
            <div>
                <strong>CODIGO DE CONTROL: </strong>
            </div>
            <div>
                <strong>FECHA LIMITE DE EMISION: </strong>
            </div>
        </div>
    </div>
</main>

    
<div class="mb-4">
    <?php echo DNS2D::getBarcodeHTML($datosQR,'QRCODE',3,3); ?>        
</div>

<footer>
    <p>
        Ley Nro 453: Los servicios deben suministrarse en condiciones de inocuidad, calidad y seguridad
    </p>
    <p>"ESTA FACTURA CONTRIBUYE AL DESARROLLO DEL PAIS, EL USO ILICITO DE ESTA SERA SANCIONADO DE ACUERDO A LA LEY"</p>
</footer>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/factura/create.blade.php ENDPATH**/ ?>