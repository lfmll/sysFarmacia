

<?php $__env->startSection('title', 'Ventas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Detalle de Ventas</h3>                                                    
                </div>
                <div class="card-body">
                    <div class="dataTables_wrapper dt-bootstrap4">
                        <table id="tventa" class="table table-bordered">
                            <thead style="background-color: #2ab27b">
                                <tr>
                                    <th>No</th>
                                    <th>Concepto</th>
                                    <th>Cantidad</th>
                                    <th>Precio Unitario</th>
                                    <th>SubTotal</th>                                                                                                     
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detalleventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalleventa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <?php if(!is_null($detalleventa->lote->medicamento)): ?>
                                        <td><?php echo e($detalleventa->lote->medicamento->nombre_comercial); ?></td>
                                    <?php endif; ?>
                                    <?php if(!is_null($detalleventa->lote->insumo)): ?>
                                        <td><?php echo e($detalleventa->lote->insumo->nombre); ?></td>
                                    <?php endif; ?>
                                    <?php if(!is_null($detalleventa->lote->producto)): ?>
                                        <td><?php echo e($detalleventa->lote->producto->nombre); ?></td> 
                                    <?php endif; ?>
                                    <td><?php echo e($detalleventa->cantidad); ?></td>
                                    <td><?php echo e($detalleventa->precio_venta); ?></td>
                                    <td><?php echo e($detalleventa->cantidad * $detalleventa->precio_venta); ?></td>                            
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>                                      
                    </div>
                </div>
            </div>    
        </div>    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/venta/detalle.blade.php ENDPATH**/ ?>