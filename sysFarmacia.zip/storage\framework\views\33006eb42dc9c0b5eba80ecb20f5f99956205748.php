<div class="card-body">
    <?php echo Form::open(['url' => $url, 'method' => $method, 'files' => true]); ?> 
    <h5>Datos Generales</h5>
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">        
                <?php echo e(Form::label('tipodoc', 'Tipo de Documento')); ?>

                <?php echo Form::select('tipo_documento', $tipo_documento, $cliente->tipo_documento, ['class'=>'form-control','placeholder'=>'Tipo de Documento','required']); ?>

            </div>
        </div>                
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo e(Form::label('nrodoc', 'Nro Documento')); ?>

                <?php echo e(Form::text('numero_documento',$cliente->numero_documento,['class'=>'form-control', 'placeholder'=>'Numero de Documento','required'])); ?>

            </div>    
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo e(Form::label('complemento', 'Complemento')); ?>

                <?php echo e(Form::text('complemento',$cliente->complemento,['class'=>'form-control', 'placeholder'=>'Numero de Documento'])); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo e(Form::label('nombre', 'Nombre o Razon Social')); ?>

                <?php echo e(Form::text('nombre',$cliente->nombre,['class'=>'form-control', 'placeholder'=>'Nombre','required'])); ?>

            </div>
        </div>        
    </div>
    <h5>Datos de Contacto</h5>
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo e(Form::label('correo', 'Correo Electronico')); ?>

                <?php echo e(Form::text('correo',$cliente->correo,['class'=>'form-control', 'placeholder'=>'Correo','required'])); ?>

            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <?php echo e(Form::label('telefono', 'Telefono')); ?>

                <?php echo e(Form::number('telefono',$cliente->telefono,['class'=>'form-control','placeholder'=>0, 'min'=>'0'])); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <?php echo e(Form::label('direccion','Direccion')); ?>

                <?php echo e(Form::text('direccion',$cliente->direccion,['class'=>'form-control', 'placeholder'=>'Direccion'])); ?>

            </div> 
        </div>
    </div>
                       
    
</div>
<div class="card-footer">
    <div class="float-left">
        <a type="submit" class="btn btn-default" href="<?php echo e(url('/cliente')); ?>">Cancelar</a>    
    </div>   
    <div class="float-right">
        <input type="submit" value="Guardar" class="btn btn-info">
    </div>
</div>
<?php echo Form::close(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/cliente/form.blade.php ENDPATH**/ ?>