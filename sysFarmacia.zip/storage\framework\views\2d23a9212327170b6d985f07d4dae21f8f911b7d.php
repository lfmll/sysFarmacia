<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>        
        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
        }
        .main {
            font-size: 12pt;
        }
    </style>
    <title>Reporte de Medicamento</title>
</head>
<body>
    <div class="container">
        <table width="100%">
            <thead>
                <tr>
                    <th align="left">Nombre Comercial</th>
                    <th align="left">Nombre Genérico</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($medicamento->nombre_comercial); ?></td>
                    <td><?php echo e($medicamento->nombre_generico); ?></td>
                </tr>
            </tbody>
        </table> 
            
        <div class="row">
            <?php if(!is_null($medicamento->composicion)): ?>
            <div class="col-sm-6">
                <h5>Composición:</h5><span><?php echo e($medicamento->composicion); ?></span>
            </div>
            <?php endif; ?>
            <?php if(!is_null($medicamento->observacion)): ?>
            <div class="col-sm-6">
                <h5>Observación:</h5><span><?php echo e($medicamento->observacion); ?></span>
            </div>
            <?php endif; ?>
        </div>                            
        <div class="row">
            <?php if(!is_null($medicamento->indicacion)): ?>
            <div class="col-sm-6">
                <h5>Indicación:</h5><span><?php echo e($medicamento->indicacion); ?></span>
            </div>
            <?php endif; ?>
            <?php if(!is_null($medicamento->contraindicacion)): ?>
            <div class="col-sm-6">
                <h5>Contra-Indicación:</h5><span><?php echo e($medicamento->contraindicacion); ?></span>                 
            </div>                                       
            <?php endif; ?> 
        </div>                           
        <div class="row">
            <div class="col-sm-6">                
                <h5>Unidad Medida:</h5><span><?php echo e($unidad_medida->descripcion); ?></span>                
            </div>        
            <div class="col-sm-6">
                <h5>Vía Administración:</h5><span><?php echo e($medicamento->via->descripcion); ?></span>                        
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <h5>Acciones Terapéuticas:</h5>
                <ul>
                    <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($clase->nombre); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </ul>                
            </div> 
        </div>
        <div class="row">
            <div class="col-sm-12">
                <h5>Dosís:</h5>
                <ul class="list-group">                    
                    <li class="list-group-item disabled">Lactantes: <?php echo e($medidamedicamento1); ?> <br> <?php echo e($dosis_estandar1); ?></li>
                    <li class="list-group-item disabled">Infantes:  <?php echo e($medidamedicamento2); ?> <br> <?php echo e($dosis_estandar2); ?></li>
                    <li class="list-group-item disabled">Adultos:   <?php echo e($medidamedicamento3); ?> <br> <?php echo e($dosis_estandar3); ?></li>
                </ul>  
            </div>                                   
        </div>                                          
    </div>
    
    <div class="footer">
        <hr>
        <h3 style="text-align:right"><?php echo e($fecha); ?></h3>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/medicamento/reporteMedicamento.blade.php ENDPATH**/ ?>