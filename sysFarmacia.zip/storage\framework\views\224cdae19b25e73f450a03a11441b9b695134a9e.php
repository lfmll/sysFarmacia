

<?php $__env->startSection('title', 'Cliente'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">   
        <div class="card card-info">
            <div class="card-header">
                <h2 class="card-title"><i class="fas fa-fw fa-user"></i>Registro de Clientes</h2>                
            </div>                         
                <?php echo $__env->make('cliente.form',['cliente'=>$cliente,'url'=>'/cliente','method'=>'POST'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>            
    </div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/cliente/create.blade.php ENDPATH**/ ?>