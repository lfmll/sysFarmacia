<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
        }
    </style>
    <title>Reporte de Clientes</title>
</head>
<body>
    <header>
        <h2 style="text-align:center">Listado de Clientes</h2>
    </header>
    <main>
        <table width="100%">
            <thead>
                <tr>
                    <th>No</th> 
                    <th>Tipo Doc</th>               
                    <th>Nro Doc</th>
                    <th>Complemento</th>
                    <th>Nombre o Razon Social</th>
                    <th>Correo</th>
                    <th>Telefono</th>                    
                    <th>Direccion</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($cliente->tipo_documento); ?></td>
                    <td><?php echo e($cliente->numero_documento); ?></td>
                    <td><?php echo e($cliente->complemento); ?></td>
                    <td><?php echo e($cliente->nombre); ?></td>
                    <td><?php echo e($cliente->correo); ?></td>
                    <td><?php echo e($cliente->telefono); ?></td>
                    <td><?php echo e($cliente->direccion); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>
    <hr>
    <footer>
        <h3 style="text-align:right"><?php echo e($fecha); ?></h3>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/cliente/reporte.blade.php ENDPATH**/ ?>