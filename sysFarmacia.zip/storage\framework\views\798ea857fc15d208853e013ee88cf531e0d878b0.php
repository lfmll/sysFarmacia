
<?php $__env->startSection('title','Eventos_Significativos'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h4>Eventos Significativos</h4>
<?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-header">
            <h5>Paquete</h5>
        </div>
        <div class="card-body">
            <table id="tpaquetes" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nro</th>
                        <th>CAFC</th>
                        <th>Cod Recepción</th>
                        <th>Sector</th>
                        <th>Cant Facturas</th>
                        <th>Estado Recepción</th>
                        <th>Opciones</th>
                    </tr>
                </thead>
            </table>        
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="card-footer">
    <a href="#" class="btn btn-success"><i class="fa fa-plus-circle"></i> Iniciar Evento</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/factura/eventos.blade.php ENDPATH**/ ?>