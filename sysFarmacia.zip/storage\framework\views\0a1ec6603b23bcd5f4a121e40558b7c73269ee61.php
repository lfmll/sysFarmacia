

<?php $__env->startSection('title', 'Apertura de Caja'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::open(['url' => '/caja', 'method' => 'POST', 'id'=>'FApertura']); ?>       
        <?php echo e(Form::token()); ?>  
        <div class="col-md-6">   
            <div class="card card-info">
                <div class="card-header with-border">
                    <h3 class="card-title">Apertura de Caja</h3>                
                </div> 
                <div class="card-body">                
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group row">
                                    <?php echo Form::label('Fecha', 'Fecha'); ?>

                                    <div class="col-sm-4">
                                        <?php echo Form::label('fecha', $fecha); ?>

                                        <?php echo Form::label('hora_inicio', $hora_inicio); ?>

                                        <input type="hidden" name="fecha" id="efecha" value=<?php echo e($fecha); ?>>
                                        <input type="hidden" name="hora_inicio" id="ehora_inicio" value=<?php echo e($hora_inicio); ?>>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <?php echo Form::label('Monto de Apertura', 'Monto de Apertura'); ?>

                                    <div class="col-sm-6">
                                        <?php echo Form::number('monto_apertura', null, ['class'=>'form-control', 'placeholder'=>'0.00', 'step'=>'any', 'required']); ?>

                                    </div>                                    
                                </div>
                            </div>                         
                        </div>                    
                    </div>                
                </div>
                <div class="card-footer">
                    <div class="form-group">
                        <div class="float-left">
                            <a type="submit" class="btn btn-default btn-lg" href="<?php echo e(url('/caja')); ?>">Cancelar</a>    
                        </div>
                        <div class="float-right">
                            <button type="submit" class="btn btn-success btn-lg">Guardar</button>  
                        </div>            
                    </div>                
                </div>
            </div>            
        </div>
    <?php echo Form::close(); ?>

    <div id="spinner" style="display: none;" class="text-center mt-3">
        <div class="spinner-border text-success" role="status">
            <span class="sr-only">Cargando...</span>
        </div>
        <p>Cargando, por favor espera...</p>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script src="js/sweetalert.min.js"></script>
    <script>
        document.getElementById('FApertura').addEventListener('submit', function () {
            document.getElementById('spinner').style.display = 'block';
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/caja/create.blade.php ENDPATH**/ ?>