

<?php $__env->startSection('title', 'Lote'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-warning">
                <div class="card-header">
                    <div class="row">
                        <div class="col-sm-10">                            
                            <a href="<?php echo e(url('#')); ?>" class="btn btn-warning"><i class="fa fa-receipt fa-lg"></i></a>
                        </div>
                        <div class="col-sm-2">
                            <a href="<?php echo e(url('listaLotes')); ?>" class="btn btn-warning"><i class="fa fa-print"></i> Imprimir</a>
                        </div>                    
                    </div>
                </div>
                <div class="card-body">
                    <div class="dataTables_wrapper dt-bootstrap4">
                        <table id="tlote" class="table table-bordered">
                            <thead>
                                <tr>                                    
                                    <th>Nro</th>
                                    <th>Cantidad</th>
                                    <th>Fecha Vencimiento</th>
                                    <th>Laboratorio</th>
                                    <th>Concepto</th>
                                    <th>Precio Compra</th>
                                    <th>Precio Venta</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>                                    
                                    <td><?php echo e($lote->numero); ?></td>
                                    <td><?php echo e($lote->cantidad); ?></td>
                                    <td><?php echo e($lote->fecha_vencimiento); ?></td>
                                    <?php if(!is_null($lote->laboratorio)): ?>
                                        <td>
                                            <?php echo e($lote->laboratorio->nombre); ?>

                                        </td>
                                    <?php else: ?>
                                        <td></td>
                                    <?php endif; ?>                                    
                                    <?php if(!is_null($lote->medicamento)): ?>
                                        <td>
                                            <?php echo e($lote->medicamento->nombre_comercial); ?>

                                        </td>
                                    <?php endif; ?>  
                                    <td><?php echo e($lote->precio_compra); ?></td>
                                    <td><?php echo e($lote->precio_venta); ?></td>
                                    <td>
                                    <a href="<?php echo e(url('/lote/'.$lote->id.'/edit')); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Editar</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>                                      
                    </div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(url('/lote/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nuevo</a>
                </div>
            </div>    
        </div>    
    </div>        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tlote').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [4, 8, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/lote/index.blade.php ENDPATH**/ ?>