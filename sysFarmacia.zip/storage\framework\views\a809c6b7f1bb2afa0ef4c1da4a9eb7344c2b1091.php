

<?php $__env->startSection('title', 'Lista de Arqueo'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Conteo Semanal</h3>                                                    
            </div>
            <div class="card-body">
                <div class="dataTables_wrapper dt-bootstrap4">
                    <table id="tvia" class="table table-bordered">
                        <thead>
                            <tr>
                                <td>Día</td>                
                                <td>Fecha</td>
                                <td>Hora de Inicio</td>
                                <td>Hora de Cierre</td>
                                <td>Egresos</td>
                                <td>Ingresos</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($dias[(date('N', strtotime($caja->fecha)))-1]); ?></td>
                                <td><?php echo e($caja->fecha); ?></td>
                                <td><?php echo e($caja->hora_inicio); ?></td>
                                <?php if(is_null($caja->hora_fin)): ?>
                                    <td></td>
                                <?php else: ?>
                                    <td><?php echo e($caja->hora_fin); ?></td>
                                <?php endif; ?>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                      
                </div>
            </div>
            
        </div>    
    </div>    
</div>
        

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tvia').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [7, 7, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
    <script src="js/sweetalert.min.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/caja/index.blade.php ENDPATH**/ ?>