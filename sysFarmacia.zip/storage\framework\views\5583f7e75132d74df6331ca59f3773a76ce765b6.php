

<?php $__env->startSection('title', 'Ventas'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Ventas</h3>                                                    
            </div>
            <div class="card-body">
                <div class="dataTables_wrapper dt-bootstrap4">
                    <table id="tventa" class="table table-bordered">
                        <thead>
                            <tr>
                                <td>Fecha Venta</td>            
                                <!-- <td>Forma Pago</td>  -->
                                <td>Total</td>                                                 
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($venta->fecha_venta); ?></td>
                                
                                <td><?php echo e($venta->total); ?></td>
                                <td>                                
                                    <a href="<?php echo e(url('/venta/'.$venta->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-bars"></i> Detalle</a>
                                </td>                               
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                      
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(url('/venta/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nueva venta</a>
            </div>
        </div>    
    </div>    
</div>
        

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tventa').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [4, 8, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/venta/index.blade.php ENDPATH**/ ?>