
<?php $__env->startSection('title','Eventos_Significativos'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h4>Eventos Significativos</h4>
<?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-header">
            <h6><b>Evento:</b> <?php echo e($evento->id); ?></h6>
            <h6><b>Fecha Inicio:</b> <?php echo e(date('d-m-Y', strtotime($evento->fechaInicioEvento))); ?> |<b>Fecha Fin:</b><?php if(is_null($evento->fechaFinEvento)): ?> Sin Asignar <?php else: ?> <?php echo e(date('d-m-Y', strtotime($evento->fechaFinEvento))); ?> <?php endif; ?></h6>
        </div>
        <div class="card-body">            
            <ul class="list-group list-group-horizontal">                            
                <li class="list-group-item"><b>CAFC:</b> <?php if(is_null($evento->cafc)): ?> <br>No Aplica <?php else: ?> <br><?php echo e($evento->cafc); ?> <?php endif; ?></li>
                <li class="list-group-item"><b>Cod Recepcion:</b> <?php echo e($evento->codigoRecepcion); ?></li>
                <li class="list-group-item"><b>Evento:</b> <br><?php echo e($evento->descripcion); ?></li>
                <li class="list-group-item"><b>Cant Facturas:</b> <br><?php echo e($evento->cantidadFacturas); ?></li>
                <li class="list-group-item"><b>Estado:</b><br><span class="badge bg-secondary"><?php echo e($evento->estado); ?></span></li>
                <li class="list-group-item"><b>Acciones:</b><br>
                    <div class="btn-group d-flex" role="group">
                        <a class="btn btn-warning flex-fill" data-toggle="modal" data-target="#paqueteModal<?php echo e($evento->id); ?>">Paquete</a>
                        <?php echo Form::open(['url'=>'/evento/'.$evento->id, 'method'=>'PATCH','class'=>'d-inline-block']); ?>

                        <a class="btn btn-success flex-fill cerrar">Validar</a>
                        <?php echo Form::close(); ?>

                    </div>                                        
                </li>
            </ul>                        
        </div>
    </div>
    <!-- Modal Paquete Facturas -->
    <div class="modal fade" id="paqueteModal<?php echo e($evento->id); ?>" tabindex="-1" role="dialog" aria-labelledby="paqueteModalLabel<?php echo e($evento->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paqueteModalLabel<?php echo e($evento->id); ?>">Paquete de Facturas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nro Factura</th>
                                <th>NIT/CI</th>
                                <th>Cliente</th>
                                <th>Fecha</th>
                                <th>Monto</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $evento->facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($factura->numeroFactura); ?></td>
                                    <td><?php echo e($factura->numeroDocumento); ?></td>
                                    <td><?php echo e($factura->venta->cliente->nombre); ?></td>
                                    <td><?php echo e(date('d-m-Y h:i A', strtotime($factura->fechaEmision))); ?></td>
                                    <td><?php echo e($factura->montoTotal); ?></td>
                                    <td><span class="badge badge-pill badge-primary"><?php echo e($factura->estado); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>    
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal Paquete Facturas -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="card-footer">
    <a href="<?php echo e(url('/evento/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Iniciar Evento</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $('.cerrar').on('click', function(e) {
            e.preventDefault();
            var form = $(this).parents('form');
            
            Swal.fire({
                title: '¿Está Seguro?',
                text: "Cerrar Evento Significativo",
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, Cerrar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.value) {
                    form.submit();            
                }
                
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('.abrir-modal').click(function(e) {
            e.preventDefault(); // Evita que el enlace recargue la página
            var id = $(this).data('id');
            $('#paqueteModal' + id).modal('show');
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/evento/index.blade.php ENDPATH**/ ?>