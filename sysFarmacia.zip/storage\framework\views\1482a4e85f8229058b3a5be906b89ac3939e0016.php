

<?php $__env->startSection('title', 'Medicamento'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-info">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-4">                            
                        <a href="<?php echo e(url('#')); ?>" class="btn btn-info"><i class="fa fa-medkit fa-lg"></i></a>
                    </div>
                    <div class="col-sm-6">
                        <h5>Medicamentos</h5>
                    </div>
                    <div class="col-sm-2">
                        <a href="<?php echo e(url('listaMedicamentos')); ?>" class="btn btn-info"><i class="fa fa-print"></i> Imprimir</a>
                    </div>                    
                </div>                                                   
            </div>
            <div class="card-body">
                <div class="dataTables_wrapper dt-bootstrap4">
                    <table id="tmedicamento" class="table table-bordered">
                        <thead>
                            <tr>
                                <td>ID</td>
                                <td>Nombre Comercial</td>    
                                <td>Nombre Genérico</td>            
                                <td>Stock</td>
                                <td>Stock Mínimo</td>
                                <td>Acciones</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $medicamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($medi->id); ?></td>
                                <td><?php echo e($medi->nombre_comercial); ?></td>
                                <td><?php echo e($medi->nombre_generico); ?></td>
                                <td><?php echo e($medi->stock); ?></td>
                                <td><?php echo e($medi->stock_minimo); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/medicamento/'.$medi->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-bullseye"></i> Mostrar</a>
                                    <a href="<?php echo e(url('/medicamento/'.$medi->id.'/edit')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Editar</a>
                                    <a href="<?php echo e(url('/lote/'.$medi->id.'/create_medicamento')); ?>" class="btn btn-warning btn-sm"><i class="fa fa-fw fa-receipt"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>                                      
                </div>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(url('/medicamento/create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Nuevo</a>
            </div>
        </div>    
    </div>    
</div>
        

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
    <script>
        $(function () {
            $('#tmedicamento').DataTable({
                "responsive" : false,
                "paging": true,
                "lengthMenu": [4, 8, "All"],
                "searching": true,
                "ordering": false,
                "info": false,
                "language" : {"url": "//cdn.datatables.net/plug-ins/1.11.3/i18n/es_es.json"},
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sysFarmacia\resources\views/medicamento/index.blade.php ENDPATH**/ ?>