DROP TABLE IF EXISTS actividad_documentos;

CREATE TABLE `actividad_documentos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_actividad` varchar(10) NOT NULL,
  `codigo_documento_sector` varchar(5) NOT NULL,
  `tipo_documento_sector` varchar(25) NOT NULL,
  `cuis_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS agencias;

CREATE TABLE `agencias` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(5) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `departamento` varchar(50) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `estado` char(1) NOT NULL,
  `empresa_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO agencias VALUES("1","0","Casa Matriz","Santa Cruz","Santa Cruz","barrio prueba calle test 1","70877412","A","1","2024-07-05 03:29:14","2024-07-05 03:29:14");

DROP TABLE IF EXISTS agentes;

CREATE TABLE `agentes` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `telefonos` varchar(255) NOT NULL,
  `anotacion` varchar(255) DEFAULT NULL,
  `laboratorio_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS ajustes;

CREATE TABLE `ajustes` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `driver` varchar(5) DEFAULT NULL,
  `host` varchar(5) DEFAULT NULL,
  `port` varchar(5) DEFAULT NULL,
  `encryption` varchar(10) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `from` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `punto_venta_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO ajustes VALUES("1","","","","","luisfernandomedinallorenti@gmail.com","","","","1","2024-07-05 03:29:14","2024-07-05 03:29:14");

DROP TABLE IF EXISTS cajas;

CREATE TABLE `cajas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `monto_apertura` decimal(12,2) NOT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time DEFAULT NULL,
  `b200` int(11) DEFAULT NULL,
  `b100` int(11) DEFAULT NULL,
  `b50` int(11) DEFAULT NULL,
  `b20` int(11) DEFAULT NULL,
  `b10` int(11) DEFAULT NULL,
  `m5` int(11) DEFAULT NULL,
  `m2` int(11) DEFAULT NULL,
  `m1` int(11) DEFAULT NULL,
  `m05` int(11) DEFAULT NULL,
  `m02` int(11) DEFAULT NULL,
  `m01` int(11) DEFAULT NULL,
  `gastos` decimal(12,2) DEFAULT NULL,
  `ganancias` decimal(12,2) DEFAULT NULL,
  `total` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO cajas VALUES("1","0.00","2024-07-05","20:45:00","","","","","","","","","","","","","","","","2024-07-06 00:45:25","2024-07-06 00:45:25");

DROP TABLE IF EXISTS catalogos;

CREATE TABLE `catalogos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_actividad` varchar(10) NOT NULL,
  `descripcion_producto` varchar(500) NOT NULL,
  `cuis_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS clases;

CREATE TABLE `clases` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `clase` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO clases VALUES("1","(A01) Estomalógicos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("2","(A02) Antiácidos, antiflatulentos y antiulcerosos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("3","(A03) Fármacos para los desórdenes gastrointestinales","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("4","(A04) Antieméticos y antinauseosos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("5","(A05) Colagogos y protectores hepáticos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("6","(A06) Laxantes","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("7","(A07) Antidiarreicos, susbs. de electrolitos orales, antiiflamatorios y antiinfecciosos intestinales","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("8","(A08) Preparados antiobesidad, excluyendo los dietéticos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("9","(A09) Digestivos incluyendo enzimas digestivas","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("10","(A10) Productos utilizados para la diabetes","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("11","(A11) Vitaminas","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("12","(A12) Suplementos minerales","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("13","(A13) Tónicos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("14","(A14) Anabólicos, sistémicos","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("15","(A15) Estimulantes del apetito","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("16","(A16) Otros productos para el tracto alimentario y el metabolismo","(A) Tracto alimentario y metabolismo","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("17","(B01) Agentes antitrombóticos","(B) Sangre y aparato hematopoyético","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("18","(B02) Antihemorrágicos","(B) Sangre y aparato hematopoyético","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("19","(B03) Antianémicos","(B) Sangre y aparato hematopoyético","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("20","(C01) Terapia cardiaca","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("21","(C02) Antihipertensivos","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("22","(C03) Diuréticos","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("23","(C04) Vasodilatadores periféricos","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("24","(C05) Vasoprotectores","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("25","(C07) Betabloqueantes","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("26","(C08) Antagonista del calcio","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("27","(C09) Agentes activos en el sistema en angiotensinas y renina","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("28","(C010) Preparaciones antiateroma/Reguladoras de lípidos","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("29","(C011) Productos para la terapia múltiple cardiovascular","(C) Sistema cardiovascular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("30","(D01) Antimicóticos dermatológicos","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("31","(D02) Emolientes protectores","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("32","(D03) Agentes curativos, heridas","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("33","(D04) Antipruriginosos, incluyendo antihistamínicos tópicos, anestésicos, etc","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("34","(D05) Productos no esteorideos para transtornos inflamatorios de la piel","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("35","(D06) Antivirales y antibacteriales tópicos","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("36","(D07) Corticosteroides tópicos","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("37","(D08) Antisépticos tópicos","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("38","(D09) Apósitos medicamentosos","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("39","(D10) Preparados contra acné","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("40","(D11) Otros preparados dermatológicos","(D) Dermatológicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("41","(G01) Antiinfecciosos y Antisépticos ginecológicos","(G) Sistema genitourinario y hormonas sexuales","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("42","(G02) Otros productos ginecológicos","(G) Sistema genitourinario y hormonas sexuales","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("43","(G03) Hormonas sexuales y productos con efectos deseados similares, solo acción sistémica","(G) Sistema genitourinario y hormonas sexuales","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("44","(G04) Urológicos","(G) Sistema genitourinario y hormonas sexuales","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("45","(H01) Hormonas hipofisarias e hipotalámicas y sus análogos","(H) Hormonales sistémicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("46","(H02) Corticosteroides para uso sistémico","(H) Hormonales sistémicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("47","(H03) Terapia tiroidea","(H) Hormonales sistémicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("48","(H04) Hormonas pancreáticas","(H) Hormonales sistémicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("49","(H05) Homeostasis del calcio","(H) Hormonales sistémicos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("50","(J01) Antibacterianos sistémicos","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("51","(J02) Agentes para infecciones fúngicas sistémicas","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("52","(J03) Sulfonamidas sistémicas","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("53","(J04) Antimicobacteriales","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("54","(J05) Antivirales sistémicos","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("55","(J06) Sueros gammaglobulinas","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("56","(J07) Vacunas","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("57","(J08) Otros antiinfecciosos","(J) Antiinfecciosos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("58","(K01) Soluciones intravenosas","(K) Soluciones hospitalarias","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("59","(K02) Expansores del plasma","(K) Soluciones hospitalarias","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("60","(K03) Sangre y sustitutos del plasma","(K) Soluciones hospitalarias","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("61","(K04) Soluciones inyectables/Infusiones aditivas (<100 ml)","(K) Soluciones hospitalarias","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("62","(K06) Soluciones diálisis","(K) Soluciones hospitalarias","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("63","(L01) Antineoplásicos","(L) Antineoplásicos e inmunomoduladores","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("64","(L02) Terapia hormonal citostástica","(L) Antineoplásicos e inmunomoduladores","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("65","(L03) Agentes inmunoestimulantes","(L) Antineoplásicos e inmunomoduladores","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("66","(L04) Agentes inmunosupresores","(L) Antineoplásicos e inmunomoduladores","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("67","(M01) Preparados antiinflamatorios y antirreumáticos","(M) Sistema músculo esquelético","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("68","(M02) Antirreumáticos tópicos","(M) Sistema músculo esquelético","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("69","(M03) Relajantes musculares","(M) Sistema músculo esquelético","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("70","(M04) Antigotosos","(M) Sistema músculo esquelético","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("71","(M05) Drogas para el tratamiento de enfermedades óseas","(M) Sistema músculo esquelético","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("72","(M09) Otras drogas para desórdenes del sistema musculoesqueléticos","(M) Sistema músculo esquelético","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("73","(N01) Anestésicos","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("74","(N02) Analgésicos","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("75","(N03) Antiepilépticos","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("76","(N04) Antiparkinsonianos","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("77","(N05) Psicolépticos","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("78","(N06) Psicoanlépticos excluyendo preparados antiobesidad","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("79","(N07) Otros productos para SNC","(N) Sistema nervioso central","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("80","(P01) Antiprotozoarios","(P) Parasitología","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("81","(P02) Antihelmínticos","(P) Parasitología","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("82","(P03) Ectoparasiticidas, incluyendo escabicidas, insecticidas y repelentes","(P) Parasitología","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("83","(R01) Preparados nasales","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("84","(R02) Preparados para la garganta","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("85","(R03) Productos COPD y antiasma","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("86","(R04) Revulsivos y otros inhalantes","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("87","(R05) Preparados para el resfriado y la tos","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("88","(R06) Antihistamínicos sistémicos","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("89","(R07) Otros preparados para el sistema respiratorio","(R) Sistema respiratorio","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("90","(S01) Oftalmológicos","(S) Órganos de los sentidos","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("91","(S02) Otológicos","(S) Órganos de los sentidos","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("92","(V03) Demás productos terapéuticos","(V) Varios","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("93","(V06) Agentes para dietas","(V) Varios","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("94","(V07) Productos no terapéuticos","(V) Varios","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("95","(V08) Medios de contraste","(V) Varios","2024-07-06 00:45:26","2024-07-06 00:45:26");

DROP TABLE IF EXISTS clases_medicamentos;

CREATE TABLE `clases_medicamentos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `medicamento_id` smallint(5) unsigned NOT NULL,
  `clase_id` smallint(5) unsigned NOT NULL,
  `estado` char(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS clientes;

CREATE TABLE `clientes` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tipo_documento` varchar(50) NOT NULL,
  `numero_documento` varchar(30) NOT NULL,
  `complemento` varchar(30) DEFAULT NULL,
  `nombre` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `telefono` varchar(25) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `estado` char(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS codigos;

CREATE TABLE `codigos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_caeb` varchar(10) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `tipo_actividad` char(1) NOT NULL,
  `cuis_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS compras;

CREATE TABLE `compras` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `comprobante` varchar(15) DEFAULT NULL,
  `fecha_compra` datetime NOT NULL,
  `agente_id` smallint(5) unsigned DEFAULT NULL,
  `pago_compra` decimal(10,2) NOT NULL,
  `cambio_compra` decimal(10,2) NOT NULL,
  `glosa` varchar(255) DEFAULT NULL,
  `forma_pago` varchar(255) NOT NULL,
  `estado` char(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS cufds;

CREATE TABLE `cufds` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_cufd` varchar(100) NOT NULL,
  `fecha_vigencia` datetime NOT NULL,
  `estado` char(1) NOT NULL,
  `cuis_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO cufds VALUES("1","QUFVQkRfw5NJQQ==QzlGQUU4MjRCQTY=QznCrFhzVUdIWVVBN0M0OUJGQTQ5ODNC","2024-07-07 00:44:23","A","1","2024-07-06 00:44:22","2024-07-06 00:44:22");

DROP TABLE IF EXISTS cuis;

CREATE TABLE `cuis` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_cuis` varchar(60) NOT NULL,
  `fecha_vigencia` datetime NOT NULL,
  `estado` char(1) NOT NULL,
  `punto_venta_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO cuis VALUES("1","825095D6","2025-05-26 11:34:54","A","1","2024-07-05 11:34:54","2024-07-05 11:34:54");

DROP TABLE IF EXISTS detalle_compras;

CREATE TABLE `detalle_compras` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL,
  `compra_id` smallint(5) unsigned NOT NULL,
  `lote_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS detalle_facturas;

CREATE TABLE `detalle_facturas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `actividadEconomica` varchar(255) NOT NULL,
  `codigoProductoSin` varchar(255) NOT NULL,
  `codigoProducto` varchar(255) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `cantidad` varchar(255) NOT NULL,
  `unidadMedida` varchar(255) NOT NULL,
  `precioUnitario` varchar(255) NOT NULL,
  `montoDescuento` varchar(255) NOT NULL,
  `subTotal` varchar(255) NOT NULL,
  `numeroSerie` varchar(255) NOT NULL,
  `numeroImei` varchar(255) NOT NULL,
  `factura_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS detalle_ventas;

CREATE TABLE `detalle_ventas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) NOT NULL,
  `precio_venta` decimal(10,2) NOT NULL,
  `venta_id` smallint(5) unsigned NOT NULL,
  `lote_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS empresas;

CREATE TABLE `empresas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `nit` varchar(25) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `extension` varchar(5) DEFAULT NULL,
  `sistema` varchar(50) DEFAULT NULL,
  `codigo_sistema` varchar(25) DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL,
  `modalidad` char(1) DEFAULT NULL,
  `estado` char(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO empresas VALUES("1","Laufer","8928903012","luisfernandomedinallorenti@gmail.com","","sysfarma","7C49BFA4983BC9FAE824BA6","1.0","2","A","2024-07-05 03:29:14","2024-07-05 03:29:14");

DROP TABLE IF EXISTS facturas;

CREATE TABLE `facturas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nitEmisor` varchar(255) NOT NULL,
  `razonSocialEmisor` varchar(255) NOT NULL,
  `municipio` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `numeroFactura` varchar(255) NOT NULL,
  `cuf` varchar(255) NOT NULL,
  `cufd` varchar(255) NOT NULL,
  `codigoSucursal` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `codigoPuntoVenta` varchar(255) NOT NULL,
  `fechaEmision` datetime NOT NULL,
  `nombreRazonSocial` varchar(255) NOT NULL,
  `codigoTipoDocumentoIdentidad` varchar(255) NOT NULL,
  `numeroDocumento` varchar(255) NOT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `codigoCliente` varchar(255) NOT NULL,
  `codigoMetodoPago` varchar(255) NOT NULL,
  `numeroTarjeta` varchar(255) DEFAULT NULL,
  `montoTotal` varchar(255) NOT NULL,
  `montoTotalSujetoIva` varchar(255) NOT NULL,
  `codigoMoneda` varchar(255) NOT NULL,
  `tipoCambio` varchar(255) NOT NULL,
  `montoTotalMoneda` varchar(255) NOT NULL,
  `montoGiftCard` varchar(255) NOT NULL,
  `descuentoAdicional` varchar(255) NOT NULL,
  `codigoExcepcion` varchar(255) DEFAULT NULL,
  `cafc` varchar(255) DEFAULT NULL,
  `leyenda` varchar(255) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `codigoDocumentoSector` varchar(255) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `venta_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS failed_jobs;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS formatos;

CREATE TABLE `formatos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO formatos VALUES("1","Polvos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("2","Granuladodas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("3","Cápsulas Duras","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("4","Cápsulas Blandas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("5","Tabletas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("6","Comprimidos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("7","Supositorios","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("8","Óvulos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("9","Pomadas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("10","Pastas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("11","Cremas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("12","Jaleas","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("13","Emplastos","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("14","Inyectables","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("15","Jarabes","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("16","Emulsiones","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("17","Suspensiones","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("18","Colirios","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("19","Inhaladores","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("20","Aerosoles","2024-07-06 00:45:25","2024-07-06 00:45:25");

DROP TABLE IF EXISTS laboratorios;

CREATE TABLE `laboratorios` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `procedencia` varchar(15) DEFAULT NULL,
  `anotacion` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS leyendas;

CREATE TABLE `leyendas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_actividad` varchar(10) NOT NULL,
  `descripcion_leyenda` varchar(500) NOT NULL,
  `cuis_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS lotes;

CREATE TABLE `lotes` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  `laboratorio_id` smallint(5) unsigned DEFAULT NULL,
  `medicamento_id` smallint(5) unsigned DEFAULT NULL,
  `precio_compra` decimal(8,2) DEFAULT NULL,
  `precio_venta` decimal(8,2) DEFAULT NULL,
  `ganancia` decimal(8,2) DEFAULT NULL,
  `estado` char(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS medicamentos;

CREATE TABLE `medicamentos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `nombre_comercial` varchar(50) NOT NULL,
  `nombre_generico` varchar(50) NOT NULL,
  `composicion` varchar(255) DEFAULT NULL,
  `indicacion` varchar(255) DEFAULT NULL,
  `contraindicacion` varchar(255) DEFAULT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  `stock` int(10) unsigned NOT NULL,
  `stock_minimo` int(10) unsigned NOT NULL,
  `formato_id` smallint(5) unsigned NOT NULL,
  `via_id` smallint(5) unsigned NOT NULL,
  `catalogo_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS medidas;

CREATE TABLE `medidas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO medidas VALUES("1","Lactantes","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("2","Infantes","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("3","Adultos","2024-07-06 00:45:25","2024-07-06 00:45:25");

DROP TABLE IF EXISTS medidas_medicamentos;

CREATE TABLE `medidas_medicamentos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `dosis_estandar` varchar(255) DEFAULT NULL,
  `medicamento_id` smallint(5) unsigned NOT NULL,
  `medida_id` smallint(5) unsigned NOT NULL,
  `estado` char(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS metodo_pagos;

CREATE TABLE `metodo_pagos` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS migrations;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO migrations VALUES("1","2014_10_12_000000_create_users_table","1"),
("2","2014_10_12_100000_create_password_resets_table","1"),
("3","2019_08_19_000000_create_failed_jobs_table","1"),
("4","2021_10_31_014315_create_laboratorios_table","1"),
("5","2021_10_31_200156_create_vias_table","1"),
("6","2021_10_31_220253_create_medidas_table","1"),
("7","2021_10_31_225406_create_formatos_table","1"),
("8","2021_11_02_010333_create_clases_table","1"),
("9","2021_11_06_195158_create_medicamentos_table","1"),
("10","2021_11_13_185524_create_clases_medicamentos_table","1"),
("11","2021_11_13_191132_create_medidas_medicamentos_table","1"),
("12","2021_12_16_162343_create_lotes_table","1"),
("13","2021_12_28_021440_create_agentes_table","1"),
("14","2021_12_29_142928_create_compras_table","1"),
("15","2021_12_31_190239_create_detalle_compras_table","1"),
("16","2022_01_01_200646_create_ventas_table","1"),
("17","2022_01_01_202754_create_detalle_ventas_table","1"),
("18","2022_01_20_013205_create_cajas_table","1"),
("19","2022_02_03_201058_create_facturas_table","1"),
("43","2022_02_06_214107_create_empresas_table","2"),
("44","2023_09_09_142922_create_clientes_table","2"),
("45","2023_11_21_005951_create_catalogos_table","2"),
("46","2023_11_24_205954_create_agencias_table","2"),
("47","2023_11_25_004708_create_punto_ventas_table","2"),
("48","2024_01_14_013050_create_detalle_facturas_table","2"),
("49","2024_01_16_141328_create_metodo_pagos_table","2"),
("50","2024_01_16_141634_create_actividad_documentos_table","3"),
("51","2024_02_05_183839_create_ajustes_table","3"),
("52","2024_06_06_005201_create_cuis_table","3"),
("53","2024_06_16_030414_create_cufds_table","3"),
("54","2024_06_22_014606_create_parametros_table","3"),
("55","2024_06_23_014755_create_tipo_parametros_table","3"),
("56","2024_06_29_201557_create_codigos_table","3"),
("57","2024_06_30_154219_create_leyendas_table","3");

DROP TABLE IF EXISTS parametros;

CREATE TABLE `parametros` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_clasificador` smallint(6) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `tipo_parametro_id` smallint(5) unsigned NOT NULL,
  `cuis_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS password_resets;

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS punto_ventas;

CREATE TABLE `punto_ventas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(5) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `agencia_id` smallint(5) unsigned NOT NULL,
  `user_id` smallint(5) unsigned NOT NULL,
  `estado` char(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO punto_ventas VALUES("1","0","Por defecto","1","1","A","2024-07-05 03:29:14","2024-07-05 03:29:14");

DROP TABLE IF EXISTS tipo_parametros;

CREATE TABLE `tipo_parametros` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO tipo_parametros VALUES("1","TIPO EMISION","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("2","TIPO DOCUMENTO FACTURA","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("3","TIPO DOCUMENTO IDENTIDAD","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("4","TIPO DOCUMENTO SECTOR","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("5","TIPO METODO PAGO","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("6","PAIS ORIGEN","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("7","EVENTOS SIGNIFICATIVOS","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("8","TIPO MONEDA","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("9","MOTIVO ANULACION","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("10","MENSAJE SERVICIOS","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("11","UNIDAD MEDIDA","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("12","TIPO PUNTO VENTA","2024-07-06 00:45:26","2024-07-06 00:45:26"),
("13","TIPO HABITACION","2024-07-06 00:45:26","2024-07-06 00:45:26");

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users VALUES("1","luis","luisfernandomedinallorenti@gmail.com","","$2y$10$v0u6qs4VcCtg5DZ9xw13.erh0hTx.SEiu33qYR0YI4aS99hd2Faxm","","2024-07-04 01:18:57","2024-07-04 01:18:57");

DROP TABLE IF EXISTS ventas;

CREATE TABLE `ventas` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `descuento` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `monto_giftcard` decimal(10,2) NOT NULL,
  `monto_pagar` decimal(10,2) NOT NULL,
  `importe_iva` decimal(10,2) NOT NULL,
  `cambio_venta` decimal(10,2) NOT NULL,
  `literal` varchar(255) NOT NULL,
  `estado` char(255) NOT NULL,
  `metodo_pago_id` smallint(5) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS vias;

CREATE TABLE `vias` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO vias VALUES("1","Oral","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("2","Sublingual","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("3","Tópica","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("4","Ótica","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("5","Transdérmica","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("6","Rectal","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("7","Parental Intravenosa","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("8","Parental Intramuscular","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("9","Parental Subcutánea","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("10","Vaginal","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("11","Inhalatoria","2024-07-06 00:45:25","2024-07-06 00:45:25"),
("12","Oftalmológica","2024-07-06 00:45:25","2024-07-06 00:45:25");

